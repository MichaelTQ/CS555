package testCases;

import static org.junit.Assert.*;

import org.junit.Test;

public class T08_CheckFAMCTags {

	@Test
	public void test() {
		assertEquals(1, 1);
	}

}
