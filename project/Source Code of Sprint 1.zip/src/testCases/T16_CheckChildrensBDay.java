package testCases;

import static org.junit.Assert.*;

import org.junit.Test;

public class T16_CheckChildrensBDay {

	@Test
	public void test() {
		assertEquals(true, true);
	}

}
