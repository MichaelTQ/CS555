package testCases;

import static org.junit.Assert.*;

import org.junit.Test;

public class T11_CheckHusbWifeTimes {

	@Test
	public void test() {
		assertEquals(1, 0);
	}

}
