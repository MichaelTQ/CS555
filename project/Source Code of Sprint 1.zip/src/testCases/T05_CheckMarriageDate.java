package testCases;

import static org.junit.Assert.*;

import org.junit.Test;

public class T05_CheckMarriageDate {

	@Test
	public void test() {
		assertEquals(0, 1);
	}

}
