package testCases;

import static org.junit.Assert.*;

import org.junit.Test;

public class StringReadingTest {

	@Test
	public void test() {
		assertEquals(true, true);
	}

}
